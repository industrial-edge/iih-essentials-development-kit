# IIH Essentials

A connection between IIH Essentials and Grafana.

## Setup

Please visit the configuration page for this Grafana plugin and enter the URL to your IIH Essentials DataService endpoint.

If done correctly, you should be able to add it as the data source on your dashboards, where you can select the variables of your choice.
